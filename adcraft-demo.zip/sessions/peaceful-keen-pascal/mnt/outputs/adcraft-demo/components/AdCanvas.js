// components/AdCanvas.js
// Renders the ad layers as a CSS-based preview.

export default function AdCanvas({ ad }) {
  if (!ad) return null;

  const { width, height, layers, label } = ad;

  // Scale to fit container
  const maxW = 560;
  const maxH = 560;
  const scale = Math.min(maxW / width, maxH / height, 1);
  const displayW = Math.round(width * scale);
  const displayH = Math.round(height * scale);

  const bg = layers.find((l) => l.id === 'bg');
  const hero = layers.find((l) => l.id === 'hero');
  const logo = layers.find((l) => l.id === 'logo');
  const headline = layers.find((l) => l.id === 'headline');
  const body = layers.find((l) => l.id === 'body');
  const cta = layers.find((l) => l.id === 'cta');

  const isPortrait = ad.format === 'portrait';
  const isLandscape = ad.format === 'landscape';
  const isBanner = ad.format === 'banner';

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Label */}
      <div className="text-xs text-white/30 font-mono">{label}</div>

      {/* Ad frame */}
      <div
        className="relative overflow-hidden shadow-2xl"
        style={{
          width: displayW,
          height: displayH,
          borderRadius: 12,
          background: bg?.gradient || bg?.color || '#1a1a2e',
          fontFamily: 'Inter, system-ui, sans-serif',
        }}
      >
        {/* Background gradient */}
        <div
          className="absolute inset-0"
          style={{ background: bg?.gradient || bg?.color || '#1a1a2e' }}
        />

        {/* Hero image (right or top half) */}
        {hero && hero.src && (
          <div
            className="absolute overflow-hidden"
            style={{
              right: isPortrait ? 0 : 0,
              top: isPortrait ? `${displayH * 0.2}px` : 0,
              width: isPortrait ? '100%' : `${displayW * 0.46}px`,
              height: isPortrait ? `${displayH * 0.3}px` : '100%',
              opacity: hero.opacity || 0.6,
            }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={hero.src}
              alt=""
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              onError={(e) => { e.target.parentElement.style.display = 'none'; }}
            />
            {/* Gradient overlay on hero */}
            <div
              className="absolute inset-0"
              style={{
                background: isPortrait
                  ? 'linear-gradient(to bottom, transparent 60%, rgba(0,0,0,0.6))'
                  : 'linear-gradient(to right, rgba(0,0,0,0.5) 0%, transparent 40%)',
              }}
            />
          </div>
        )}

        {/* Content area */}
        <div
          className="absolute flex flex-col"
          style={{
            left: isPortrait ? '50%' : `${displayW * 0.07}px`,
            top: isPortrait ? `${displayH * 0.1}px` : `${displayH * 0.08}px`,
            transform: isPortrait ? 'translateX(-50%)' : 'none',
            width: isPortrait ? `${displayW * 0.84}px` : `${displayW * 0.5}px`,
            alignItems: isPortrait ? 'center' : 'flex-start',
            textAlign: isPortrait ? 'center' : 'left',
            gap: `${displayH * 0.025}px`,
            zIndex: 10,
          }}
        >
          {/* Logo */}
          {logo && logo.src && (
            <div
              className="rounded-xl overflow-hidden bg-white/10"
              style={{ width: Math.round(64 * scale), height: Math.round(64 * scale) }}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={logo.src}
                alt=""
                style={{ width: '100%', height: '100%', objectFit: 'contain', padding: 4 }}
                onError={(e) => { e.target.parentElement.style.display = 'none'; }}
              />
            </div>
          )}

          {/* Headline */}
          {headline && (
            <div
              style={{
                fontSize: `${Math.max(10, Math.round(headline.fontSize * scale * 0.95))}px`,
                fontWeight: headline.fontWeight || '800',
                color: headline.color || '#fff',
                lineHeight: 1.2,
                wordBreak: 'break-word',
              }}
            >
              {headline.content}
            </div>
          )}

          {/* Body */}
          {body && !isBanner && (
            <div
              style={{
                fontSize: `${Math.max(8, Math.round(body.fontSize * scale * 0.9))}px`,
                fontWeight: body.fontWeight || '400',
                color: body.color || 'rgba(255,255,255,0.8)',
                lineHeight: 1.4,
                wordBreak: 'break-word',
                display: '-webkit-box',
                WebkitLineClamp: 3,
                WebkitBoxOrient: 'vertical',
                overflow: 'hidden',
              }}
            >
              {body.content}
            </div>
          )}

          {/* CTA button */}
          {cta && (
            <div
              className="inline-block rounded-full font-bold cursor-default select-none"
              style={{
                background: cta.bgColor || '#fff',
                color: cta.textColor || '#6366f1',
                fontSize: `${Math.max(8, Math.round(cta.fontSize * scale * 0.9))}px`,
                fontWeight: cta.fontWeight || '700',
                padding: `${Math.round(8 * scale)}px ${Math.round(20 * scale)}px`,
                whiteSpace: 'nowrap',
              }}
            >
              {cta.content}
            </div>
          )}
        </div>

        {/* Video play overlay */}
        {ad.type === 'video' && (
          <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
            <div
              className="flex items-center justify-center rounded-full bg-black/40 backdrop-blur-sm border border-white/20"
              style={{ width: Math.round(56 * scale), height: Math.round(56 * scale) }}
            >
              <svg
                style={{ width: Math.round(20 * scale), height: Math.round(20 * scale) }}
                fill="white"
                viewBox="0 0 24 24"
              >
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
          </div>
        )}

        {/* Watermark */}
        <div
          className="absolute bottom-2 right-3 text-white/20 font-medium"
          style={{ fontSize: `${Math.max(7, Math.round(9 * scale))}px` }}
        >
          AdCraft demo
        </div>
      </div>

      {/* Dimensions badge */}
      <div className="text-xs text-white/20">{ad.width} × {ad.height}px</div>
    </div>
  );
}
