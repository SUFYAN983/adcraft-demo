// components/AdEditor.js
// Right-panel editor: edit any layer property and see live preview.

import { useState } from 'react';

const SECTIONS = ['Text', 'Colors', 'Layout', 'Export'];

export default function AdEditor({ ad, setAd }) {
  const [activeSection, setActiveSection] = useState('Text');

  function updateLayer(id, patch) {
    setAd((prev) => ({
      ...prev,
      layers: prev.layers.map((l) => (l.id === id ? { ...l, ...patch } : l)),
    }));
  }

  const headline = ad.layers.find((l) => l.id === 'headline');
  const body = ad.layers.find((l) => l.id === 'body');
  const cta = ad.layers.find((l) => l.id === 'cta');
  const bg = ad.layers.find((l) => l.id === 'bg');

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-5 pb-3 border-b border-white/5">
        <div className="text-sm font-semibold mb-0.5">Edit Ad</div>
        <div className="text-xs text-white/35">{ad.label}</div>
      </div>

      {/* Section tabs */}
      <div className="flex border-b border-white/5">
        {SECTIONS.map((s) => (
          <button
            key={s}
            onClick={() => setActiveSection(s)}
            className={`flex-1 py-2.5 text-xs font-medium transition-colors ${
              activeSection === s
                ? 'text-violet-300 border-b-2 border-violet-500'
                : 'text-white/35 hover:text-white/60'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Section content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        {activeSection === 'Text' && (
          <>
            {headline && (
              <EditorGroup title="Headline">
                <TextArea
                  value={headline.content}
                  onChange={(v) => updateLayer('headline', { content: v })}
                />
                <Row label="Size">
                  <Slider
                    value={headline.fontSize}
                    min={18}
                    max={100}
                    onChange={(v) => updateLayer('headline', { fontSize: v })}
                  />
                </Row>
                <Row label="Weight">
                  <Select
                    value={headline.fontWeight}
                    options={['400', '600', '700', '800', '900']}
                    labels={['Regular', 'SemiBold', 'Bold', 'ExtraBold', 'Black']}
                    onChange={(v) => updateLayer('headline', { fontWeight: v })}
                  />
                </Row>
              </EditorGroup>
            )}
            {body && (
              <EditorGroup title="Body Text">
                <TextArea
                  value={body.content}
                  onChange={(v) => updateLayer('body', { content: v })}
                />
                <Row label="Size">
                  <Slider
                    value={body.fontSize}
                    min={12}
                    max={48}
                    onChange={(v) => updateLayer('body', { fontSize: v })}
                  />
                </Row>
              </EditorGroup>
            )}
            {cta && (
              <EditorGroup title="CTA Button">
                <TextInput
                  value={cta.content}
                  onChange={(v) => updateLayer('cta', { content: v })}
                  placeholder="Call to action text"
                />
                <Row label="Size">
                  <Slider
                    value={cta.fontSize}
                    min={12}
                    max={48}
                    onChange={(v) => updateLayer('cta', { fontSize: v })}
                  />
                </Row>
              </EditorGroup>
            )}
          </>
        )}

        {activeSection === 'Colors' && (
          <>
            {bg && (
              <EditorGroup title="Background">
                <Row label="Primary color">
                  <ColorPicker
                    value={bg.color || '#6366f1'}
                    onChange={(v) => updateLayer('bg', { color: v, gradient: `linear-gradient(135deg, ${darken(v, 50)} 0%, ${v} 60%, ${lighten(v, 40)} 100%)` })}
                  />
                </Row>
              </EditorGroup>
            )}
            {headline && (
              <EditorGroup title="Text Colors">
                <Row label="Headline">
                  <ColorPicker
                    value={headline.color || '#ffffff'}
                    onChange={(v) => updateLayer('headline', { color: v })}
                  />
                </Row>
                {body && (
                  <Row label="Body">
                    <ColorPicker
                      value={body.color || 'rgba(255,255,255,0.8)'}
                      onChange={(v) => updateLayer('body', { color: v })}
                    />
                  </Row>
                )}
              </EditorGroup>
            )}
            {cta && (
              <EditorGroup title="CTA Button">
                <Row label="Background">
                  <ColorPicker
                    value={cta.bgColor || '#ffffff'}
                    onChange={(v) => updateLayer('cta', { bgColor: v })}
                  />
                </Row>
                <Row label="Text">
                  <ColorPicker
                    value={cta.textColor || '#6366f1'}
                    onChange={(v) => updateLayer('cta', { textColor: v })}
                  />
                </Row>
              </EditorGroup>
            )}
          </>
        )}

        {activeSection === 'Layout' && (
          <EditorGroup title="Ad Format">
            <div className="text-xs text-white/40 mb-2">
              Current: {ad.label}
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'square', label: 'Square 1:1', w: 1080, h: 1080 },
                { id: 'landscape', label: 'Landscape 16:9', w: 1920, h: 1080 },
                { id: 'portrait', label: 'Story 9:16', w: 1080, h: 1920 },
                { id: 'banner', label: 'Banner', w: 1200, h: 628 },
              ].map((f) => (
                <div
                  key={f.id}
                  className={`p-2 rounded-lg border text-center text-xs transition-all cursor-default ${
                    ad.format === f.id
                      ? 'border-violet-500 bg-violet-500/10 text-white'
                      : 'border-white/8 text-white/35'
                  }`}
                >
                  <div className="font-medium">{f.label}</div>
                  <div className="text-white/25 text-xs mt-0.5">{f.w}×{f.h}</div>
                </div>
              ))}
            </div>
            <p className="text-xs text-white/25 mt-3">Format switching coming soon — go back to regenerate with a different format.</p>
          </EditorGroup>
        )}

        {activeSection === 'Export' && (
          <EditorGroup title="Export Ad">
            <p className="text-xs text-white/40 mb-4">
              In production, these connect to Creatomate / fal.ai to render final files.
            </p>
            <div className="space-y-3">
              {[
                { label: 'Download PNG', icon: '🖼️', sub: 'High-res static image', color: 'from-violet-600 to-blue-600' },
                { label: 'Download MP4', icon: '🎬', sub: '1080p video ad', color: 'from-blue-600 to-cyan-600' },
                { label: 'Copy HTML5', icon: '💻', sub: 'Interactive banner', color: 'from-emerald-600 to-teal-600' },
              ].map((btn) => (
                <button
                  key={btn.label}
                  onClick={() => alert('Export connects to Creatomate/fal.ai in production. Add your API key in .env to enable.')}
                  className={`w-full p-3 rounded-xl bg-gradient-to-r ${btn.color} hover:opacity-90 transition-opacity text-left flex items-center gap-3`}
                >
                  <span className="text-xl">{btn.icon}</span>
                  <div>
                    <div className="text-sm font-semibold text-white">{btn.label}</div>
                    <div className="text-xs text-white/60">{btn.sub}</div>
                  </div>
                </button>
              ))}
            </div>

            <div className="mt-5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <div className="text-xs text-amber-300 font-semibold mb-1">API Keys Needed</div>
              <div className="text-xs text-white/40 space-y-0.5">
                <div>CREATOMATE_API_KEY</div>
                <div>FAL_API_KEY</div>
                <div>OPENAI_API_KEY (optional)</div>
              </div>
            </div>
          </EditorGroup>
        )}
      </div>
    </div>
  );
}

/* ─── Sub-components ─────────────────────────────────────────── */

function EditorGroup({ title, children }) {
  return (
    <div>
      <div className="text-xs font-semibold text-white/50 uppercase tracking-wider mb-3">{title}</div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function Row({ label, children }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-xs text-white/40 flex-shrink-0 w-20">{label}</span>
      <div className="flex-1">{children}</div>
    </div>
  );
}

function TextArea({ value, onChange }) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      rows={3}
      className="w-full bg-white/5 border border-white/8 focus:border-violet-500 rounded-lg px-3 py-2 text-xs text-white outline-none resize-none transition-colors"
    />
  );
}

function TextInput({ value, onChange, placeholder }) {
  return (
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full bg-white/5 border border-white/8 focus:border-violet-500 rounded-lg px-3 py-2 text-xs text-white outline-none transition-colors"
    />
  );
}

function Slider({ value, min, max, onChange }) {
  return (
    <div className="flex items-center gap-2">
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="flex-1 accent-violet-500 h-1"
      />
      <span className="text-xs text-white/40 w-8 text-right">{value}</span>
    </div>
  );
}

function ColorPicker({ value, onChange }) {
  const displayVal = value.startsWith('rgba') ? '#ffffff' : value;
  return (
    <div className="flex items-center gap-2">
      <input
        type="color"
        value={displayVal}
        onChange={(e) => onChange(e.target.value)}
        className="w-8 h-8 rounded-lg border border-white/10 cursor-pointer bg-transparent"
      />
      <span className="text-xs text-white/30 font-mono">{displayVal}</span>
    </div>
  );
}

function Select({ value, options, labels, onChange }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full bg-white/5 border border-white/8 rounded-lg px-2 py-1.5 text-xs text-white outline-none"
    >
      {options.map((o, i) => (
        <option key={o} value={o} className="bg-gray-900">
          {labels ? labels[i] : o}
        </option>
      ))}
    </select>
  );
}

function darken(hex, amount) {
  try {
    const num = parseInt(hex.replace('#', ''), 16);
    const r = Math.max(0, (num >> 16) - amount);
    const g = Math.max(0, ((num >> 8) & 0xff) - amount);
    const b = Math.max(0, (num & 0xff) - amount);
    return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
  } catch { return '#1a1a2e'; }
}

function lighten(hex, amount) {
  try {
    const num = parseInt(hex.replace('#', ''), 16);
    const r = Math.min(255, (num >> 16) + amount);
    const g = Math.min(255, ((num >> 8) & 0xff) + amount);
    const b = Math.min(255, (num & 0xff) + amount);
    return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
  } catch { return '#a78bfa'; }
}
