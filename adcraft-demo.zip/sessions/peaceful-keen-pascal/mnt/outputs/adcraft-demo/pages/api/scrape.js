// pages/api/scrape.js
// Fetches a URL and extracts brand data: title, description, og:image, colors, favicon

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { url } = req.body;
  if (!url) return res.status(400).json({ error: 'URL required' });

  try {
    const targetUrl = url.startsWith('http') ? url : `https://${url}`;

    // Fetch the page HTML
    const response = await fetch(targetUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (compatible; AdCraftBot/1.0; +https://adcraft.demo)',
      },
      signal: AbortSignal.timeout(10000),
    });

    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const html = await response.text();

    // Parse meta tags with simple regex (no cheerio needed on edge)
    const extract = (pattern) => {
      const m = html.match(pattern);
      return m ? m[1].replace(/&amp;/g, '&').trim() : null;
    };

    const title =
      extract(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i) ||
      extract(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:title["']/i) ||
      extract(/<title[^>]*>([^<]+)<\/title>/i) ||
      'Your Brand';

    const description =
      extract(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i) ||
      extract(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:description["']/i) ||
      extract(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i) ||
      extract(/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']description["']/i) ||
      'Discover something amazing.';

    const ogImage =
      extract(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
      extract(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i) ||
      null;

    // Resolve relative image URLs
    const resolveUrl = (imgUrl) => {
      if (!imgUrl) return null;
      if (imgUrl.startsWith('http')) return imgUrl;
      try {
        return new URL(imgUrl, targetUrl).href;
      } catch {
        return imgUrl;
      }
    };

    // Extract theme color
    const themeColor =
      extract(/<meta[^>]+name=["']theme-color["'][^>]+content=["']([^"']+)["']/i) ||
      extract(/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']theme-color["']/i) ||
      null;

    // Get favicon
    const parsedUrl = new URL(targetUrl);
    const domain = parsedUrl.hostname;
    const favicon = `https://www.google.com/s2/favicons?sz=128&domain=${domain}`;

    // Extract brand name from domain
    const brandName = domain
      .replace(/^www\./, '')
      .split('.')[0]
      .replace(/-/g, ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase());

    // Pick a CTA based on description keywords
    const cta = pickCTA(description + ' ' + title);

    const brand = {
      url: targetUrl,
      domain,
      brandName,
      title: title.slice(0, 80),
      description: description.slice(0, 160),
      ogImage: resolveUrl(ogImage),
      favicon,
      themeColor: themeColor || '#6366f1',
      cta,
      // Suggested palette based on theme color
      palette: generatePalette(themeColor || '#6366f1'),
    };

    return res.status(200).json({ brand });
  } catch (err) {
    console.error('Scrape error:', err.message);
    return res.status(500).json({ error: err.message || 'Failed to fetch URL' });
  }
}

function pickCTA(text) {
  const t = text.toLowerCase();
  if (t.includes('shop') || t.includes('buy') || t.includes('store')) return 'Shop Now';
  if (t.includes('learn') || t.includes('course') || t.includes('education')) return 'Learn More';
  if (t.includes('sign up') || t.includes('register') || t.includes('join')) return 'Sign Up Free';
  if (t.includes('download') || t.includes('app')) return 'Download Now';
  if (t.includes('free') || t.includes('trial')) return 'Try for Free';
  if (t.includes('book') || t.includes('appoint')) return 'Book Now';
  return 'Get Started';
}

function generatePalette(hex) {
  // Return a simple 3-color palette: primary, dark, light
  return {
    primary: hex,
    dark: darken(hex, 30),
    light: lighten(hex, 40),
    text: '#ffffff',
  };
}

function darken(hex, amount) {
  try {
    const num = parseInt(hex.replace('#', ''), 16);
    const r = Math.max(0, (num >> 16) - amount);
    const g = Math.max(0, ((num >> 8) & 0xff) - amount);
    const b = Math.max(0, (num & 0xff) - amount);
    return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
  } catch {
    return '#1a1a2e';
  }
}

function lighten(hex, amount) {
  try {
    const num = parseInt(hex.replace('#', ''), 16);
    const r = Math.min(255, (num >> 16) + amount);
    const g = Math.min(255, ((num >> 8) & 0xff) + amount);
    const b = Math.min(255, (num & 0xff) + amount);
    return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
  } catch {
    return '#a78bfa';
  }
}
