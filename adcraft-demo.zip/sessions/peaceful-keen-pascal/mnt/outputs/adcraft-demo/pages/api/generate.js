// pages/api/generate.js
// Ad generation endpoint.
// Currently returns mock data. Swap in real API calls by setting env vars.
//
// Supported providers (set env vars to activate):
//   CREATOMATE_API_KEY  → Creatomate (video + image)
//   FAL_API_KEY         → fal.ai (video)
//   OPENAI_API_KEY      → DALL-E 3 (image)

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { brand, format, adType } = req.body;
  // adType: 'image' | 'video'
  // format: 'square' | 'landscape' | 'portrait' | 'banner'

  // --- REAL CREATOMATE INTEGRATION (uncomment when key is set) ---
  // if (process.env.CREATOMATE_API_KEY) {
  //   return await generateWithCreatomate(brand, format, adType, res);
  // }

  // --- REAL FAL.AI VIDEO INTEGRATION (uncomment when key is set) ---
  // if (process.env.FAL_API_KEY && adType === 'video') {
  //   return await generateWithFal(brand, format, res);
  // }

  // --- MOCK RESPONSE (always runs in demo mode) ---
  await new Promise((r) => setTimeout(r, 2200)); // simulate generation delay

  const dimensions = getDimensions(format);

  const mockAd = {
    id: `ad_${Date.now()}`,
    type: adType,
    format,
    width: dimensions.width,
    height: dimensions.height,
    label: dimensions.label,
    // For image ads: CSS-renderable ad config (no external image needed)
    layers: buildLayers(brand, format, adType),
    brand,
    createdAt: new Date().toISOString(),
  };

  return res.status(200).json({ ad: mockAd });
}

function getDimensions(format) {
  const map = {
    square:    { width: 1080, height: 1080, label: 'Square 1:1 (1080×1080)' },
    landscape: { width: 1920, height: 1080, label: 'Landscape 16:9 (1920×1080)' },
    portrait:  { width: 1080, height: 1920, label: 'Story 9:16 (1080×1920)' },
    banner:    { width: 1200, height: 628,  label: 'Banner 1200×628' },
  };
  return map[format] || map.square;
}

function buildLayers(brand, format, adType) {
  const isPortrait = format === 'portrait';
  return [
    {
      id: 'bg',
      type: 'background',
      color: brand.palette?.primary || '#6366f1',
      gradient: `linear-gradient(135deg, ${brand.palette?.dark || '#1a1a2e'} 0%, ${brand.palette?.primary || '#6366f1'} 60%, ${brand.palette?.light || '#a78bfa'} 100%)`,
    },
    {
      id: 'logo',
      type: 'image',
      src: brand.favicon,
      x: isPortrait ? '50%' : '8%',
      y: isPortrait ? '12%' : '10%',
      width: 64,
      height: 64,
    },
    {
      id: 'headline',
      type: 'text',
      content: brand.title,
      x: isPortrait ? '50%' : '8%',
      y: isPortrait ? '38%' : '32%',
      fontSize: isPortrait ? 52 : 44,
      fontWeight: '800',
      color: '#ffffff',
      maxWidth: isPortrait ? '80%' : '55%',
      align: isPortrait ? 'center' : 'left',
    },
    {
      id: 'body',
      type: 'text',
      content: brand.description,
      x: isPortrait ? '50%' : '8%',
      y: isPortrait ? '58%' : '52%',
      fontSize: isPortrait ? 28 : 22,
      fontWeight: '400',
      color: 'rgba(255,255,255,0.85)',
      maxWidth: isPortrait ? '80%' : '52%',
      align: isPortrait ? 'center' : 'left',
    },
    {
      id: 'cta',
      type: 'button',
      content: brand.cta || 'Get Started',
      x: isPortrait ? '50%' : '8%',
      y: isPortrait ? '76%' : '72%',
      bgColor: '#ffffff',
      textColor: brand.palette?.primary || '#6366f1',
      fontSize: isPortrait ? 28 : 20,
      fontWeight: '700',
    },
    ...(brand.ogImage
      ? [
          {
            id: 'hero',
            type: 'image',
            src: brand.ogImage,
            x: isPortrait ? '0%' : '52%',
            y: isPortrait ? '20%' : '0%',
            width: isPortrait ? '100%' : '48%',
            height: isPortrait ? '30%' : '100%',
            objectFit: 'cover',
            opacity: 0.7,
          },
        ]
      : []),
  ];
}
