import { useState } from 'react';
import Head from 'next/head';
import AdCanvas from '../components/AdCanvas';
import AdEditor from '../components/AdEditor';

const FORMATS = [
  { id: 'square',    label: 'Square',    sub: '1:1 · Social',        icon: '⬛' },
  { id: 'landscape', label: 'Landscape', sub: '16:9 · YouTube/TV',   icon: '🟦' },
  { id: 'portrait',  label: 'Story',     sub: '9:16 · Reels/Stories', icon: '📱' },
  { id: 'banner',    label: 'Banner',    sub: '1200×628 · OG/Meta',  icon: '🟥' },
];

const AD_TYPES = [
  { id: 'image', label: 'Static Image', icon: '🖼️', desc: 'JPG/PNG banner ad' },
  { id: 'video', label: 'Video Ad',     icon: '🎬', desc: 'MP4 animated ad' },
];

// Steps: url → brand → format → generating → editor
export default function Home() {
  const [step, setStep] = useState('url');
  const [url, setUrl] = useState('');
  const [urlError, setUrlError] = useState('');
  const [scraping, setScraping] = useState(false);
  const [brand, setBrand] = useState(null);
  const [format, setFormat] = useState('square');
  const [adType, setAdType] = useState('image');
  const [generating, setGenerating] = useState(false);
  const [ad, setAd] = useState(null);

  async function handleScrape(e) {
    e.preventDefault();
    setUrlError('');
    if (!url.trim()) return setUrlError('Please enter a URL');
    setScraping(true);
    try {
      const res = await fetch('/api/scrape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to fetch URL');
      setBrand(data.brand);
      setStep('brand');
    } catch (err) {
      setUrlError(err.message);
    } finally {
      setScraping(false);
    }
  }

  async function handleGenerate() {
    setGenerating(true);
    setStep('generating');
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ brand, format, adType }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setAd(data.ad);
      setStep('editor');
    } catch (err) {
      alert('Generation failed: ' + err.message);
      setStep('brand');
    } finally {
      setGenerating(false);
    }
  }

  function handleReset() {
    setStep('url');
    setUrl('');
    setBrand(null);
    setAd(null);
    setUrlError('');
  }

  return (
    <>
      <Head>
        <title>AdCraft – AI Ad Creator</title>
        <meta name="description" content="Create and edit ads from any URL using AI" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="min-h-screen flex flex-col">
        {/* Nav */}
        <nav className="glass border-b border-white/5 px-6 py-4 flex items-center justify-between sticky top-0 z-50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center text-sm font-bold">
              A
            </div>
            <span className="font-bold text-lg tracking-tight">AdCraft</span>
            <span className="text-xs text-white/30 ml-1">demo</span>
          </div>
          <div className="flex items-center gap-4">
            <StepIndicator step={step} />
            {step !== 'url' && (
              <button
                onClick={handleReset}
                className="text-xs text-white/40 hover:text-white/70 transition-colors px-3 py-1.5 rounded-lg hover:bg-white/5"
              >
                ← New Ad
              </button>
            )}
          </div>
        </nav>

        <main className="flex-1">
          {step === 'url' && (
            <URLStep url={url} setUrl={setUrl} onSubmit={handleScrape} loading={scraping} error={urlError} />
          )}
          {step === 'brand' && brand && (
            <BrandStep
              brand={brand}
              setBrand={setBrand}
              format={format}
              setFormat={setFormat}
              adType={adType}
              setAdType={setAdType}
              onGenerate={handleGenerate}
            />
          )}
          {step === 'generating' && <GeneratingStep adType={adType} />}
          {step === 'editor' && ad && (
            <EditorStep ad={ad} setAd={setAd} brand={brand} />
          )}
        </main>
      </div>
    </>
  );
}

/* ─── Step Indicator ──────────────────────────────────────────── */
function StepIndicator({ step }) {
  const steps = [
    { id: 'url', label: 'URL' },
    { id: 'brand', label: 'Brand' },
    { id: 'editor', label: 'Editor' },
  ];
  const idx = { url: 0, brand: 1, generating: 2, editor: 2 };
  const current = idx[step] ?? 0;

  return (
    <div className="hidden sm:flex items-center gap-1">
      {steps.map((s, i) => (
        <div key={s.id} className="flex items-center gap-1">
          <div
            className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
              i < current
                ? 'bg-violet-500 text-white'
                : i === current
                ? 'bg-violet-500/20 text-violet-300 ring-1 ring-violet-500'
                : 'bg-white/5 text-white/30'
            }`}
          >
            {i < current ? '✓' : i + 1}
          </div>
          <span className={`text-xs ${i === current ? 'text-white/70' : 'text-white/25'}`}>{s.label}</span>
          {i < steps.length - 1 && <div className="w-4 h-px bg-white/10 mx-1" />}
        </div>
      ))}
    </div>
  );
}

/* ─── URL Step ────────────────────────────────────────────────── */
function URLStep({ url, setUrl, onSubmit, loading, error }) {
  const examples = ['nike.com', 'apple.com/iphone', 'shopify.com', 'notion.so'];

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-4 py-20">
      <div className="max-w-2xl w-full text-center fade-in-up">
        {/* Hero */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-300 text-xs font-medium mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-violet-400 animate-pulse" />
          AI-Powered Ad Creation
        </div>

        <h1 className="text-5xl sm:text-6xl font-extrabold mb-4 leading-tight">
          Turn any URL into{' '}
          <span className="gradient-text">a stunning ad</span>
        </h1>
        <p className="text-white/50 text-lg mb-12 max-w-lg mx-auto">
          Paste a website link. AdCraft extracts your brand, generates the creative, and lets you edit every detail.
        </p>

        {/* Input */}
        <form onSubmit={onSubmit} className="w-full">
          <div className="flex gap-2 glass rounded-2xl p-2">
            <div className="flex-1 flex items-center gap-3 px-3">
              <svg className="w-5 h-5 text-white/30 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://yourwebsite.com"
                className="flex-1 bg-transparent text-white placeholder-white/25 outline-none text-base py-2"
                autoFocus
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 disabled:opacity-50 text-white font-semibold rounded-xl transition-all glow-purple text-sm"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg className="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="white" strokeWidth="4" />
                    <path className="opacity-75" fill="white" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Scanning...
                </span>
              ) : (
                'Create Ad →'
              )}
            </button>
          </div>
          {error && <p className="text-red-400 text-sm mt-3">{error}</p>}
        </form>

        {/* Examples */}
        <div className="flex items-center justify-center gap-2 mt-5 flex-wrap">
          <span className="text-white/25 text-xs">Try:</span>
          {examples.map((ex) => (
            <button
              key={ex}
              onClick={() => setUrl(`https://${ex}`)}
              className="text-xs px-3 py-1 rounded-full bg-white/5 hover:bg-white/10 text-white/40 hover:text-white/70 transition-all border border-white/5"
            >
              {ex}
            </button>
          ))}
        </div>
      </div>

      {/* Feature grid */}
      <div className="grid grid-cols-3 gap-4 max-w-2xl w-full mt-20 px-4">
        {[
          { icon: '🔍', title: 'Smart Extraction', desc: 'Pulls brand colors, copy, and imagery automatically' },
          { icon: '⚡', title: 'Instant Generation', desc: 'Creates image & video ads in seconds with AI' },
          { icon: '✏️', title: 'Full Editor', desc: 'Tweak every element — text, colors, layout, CTA' },
        ].map((f) => (
          <div key={f.title} className="glass rounded-xl p-4 text-center">
            <div className="text-2xl mb-2">{f.icon}</div>
            <div className="text-xs font-semibold text-white/80 mb-1">{f.title}</div>
            <div className="text-xs text-white/35">{f.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Brand Step ──────────────────────────────────────────────── */
function BrandStep({ brand, setBrand, format, setFormat, adType, setAdType, onGenerate }) {
  return (
    <div className="max-w-5xl mx-auto px-4 py-12 fade-in-up">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-1">Brand extracted ✓</h2>
        <p className="text-white/40 text-sm">Review and edit before generating your ad.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Brand card */}
        <div className="glass rounded-2xl p-6 space-y-5">
          <div className="flex items-center gap-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={brand.favicon} alt="" className="w-12 h-12 rounded-xl bg-white/10" onError={(e) => { e.target.style.display = 'none'; }} />
            <div>
              <div className="font-bold text-lg">{brand.brandName}</div>
              <div className="text-white/40 text-xs">{brand.domain}</div>
            </div>
          </div>

          {brand.ogImage && (
            <div className="relative rounded-xl overflow-hidden aspect-video bg-white/5">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={brand.ogImage} alt="" className="w-full h-full object-cover" onError={(e) => { e.target.parentElement.style.display = 'none'; }} />
            </div>
          )}

          <EditableField label="Headline" value={brand.title} onChange={(v) => setBrand({ ...brand, title: v })} multiline />
          <EditableField label="Description" value={brand.description} onChange={(v) => setBrand({ ...brand, description: v })} multiline />
          <EditableField label="CTA Button" value={brand.cta} onChange={(v) => setBrand({ ...brand, cta: v })} />

          {/* Color */}
          <div>
            <label className="text-xs text-white/40 uppercase tracking-wider mb-2 block">Brand Color</label>
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={brand.themeColor || '#6366f1'}
                onChange={(e) => setBrand({ ...brand, themeColor: e.target.value, palette: { primary: e.target.value, dark: '#1a1a2e', light: '#a78bfa', text: '#fff' } })}
                className="w-10 h-10 rounded-lg border border-white/10 cursor-pointer bg-transparent"
              />
              <span className="text-sm font-mono text-white/50">{brand.themeColor}</span>
            </div>
          </div>
        </div>

        {/* Options */}
        <div className="space-y-6">
          {/* Ad type */}
          <div className="glass rounded-2xl p-6">
            <label className="text-xs text-white/40 uppercase tracking-wider mb-3 block">Ad Type</label>
            <div className="grid grid-cols-2 gap-3">
              {AD_TYPES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setAdType(t.id)}
                  className={`p-4 rounded-xl border transition-all text-left ${
                    adType === t.id
                      ? 'border-violet-500 bg-violet-500/10 text-white'
                      : 'border-white/8 bg-white/3 text-white/50 hover:border-white/20'
                  }`}
                >
                  <div className="text-2xl mb-2">{t.icon}</div>
                  <div className="text-sm font-semibold">{t.label}</div>
                  <div className="text-xs text-white/35 mt-0.5">{t.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Format */}
          <div className="glass rounded-2xl p-6">
            <label className="text-xs text-white/40 uppercase tracking-wider mb-3 block">Format</label>
            <div className="grid grid-cols-2 gap-3">
              {FORMATS.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFormat(f.id)}
                  className={`p-3 rounded-xl border transition-all text-left ${
                    format === f.id
                      ? 'border-violet-500 bg-violet-500/10 text-white'
                      : 'border-white/8 bg-white/3 text-white/50 hover:border-white/20'
                  }`}
                >
                  <div className="text-lg mb-1">{f.icon}</div>
                  <div className="text-sm font-semibold">{f.label}</div>
                  <div className="text-xs text-white/35">{f.sub}</div>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={onGenerate}
            className="w-full py-4 bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white font-bold rounded-xl transition-all glow-purple text-base"
          >
            Generate Ad ⚡
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Generating Step ─────────────────────────────────────────── */
function GeneratingStep({ adType }) {
  const steps = [
    'Analyzing brand assets...',
    'Composing layout...',
    adType === 'video' ? 'Rendering video frames...' : 'Generating image layers...',
    'Applying brand styles...',
    'Finalizing ad...',
  ];
  const [idx] = useState(0);

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] px-4">
      <div className="text-center fade-in-up">
        <div className="relative w-24 h-24 mx-auto mb-8">
          <div className="absolute inset-0 rounded-full border-4 border-violet-500/20 animate-ping" />
          <div className="absolute inset-2 rounded-full border-4 border-t-violet-500 border-r-transparent border-b-transparent border-l-transparent animate-spin" />
          <div className="absolute inset-0 flex items-center justify-center text-3xl">
            {adType === 'video' ? '🎬' : '🖼️'}
          </div>
        </div>
        <h2 className="text-2xl font-bold mb-2">Generating your ad...</h2>
        <p className="text-white/40 text-sm mb-8">This takes just a moment</p>
        <div className="space-y-2 max-w-xs mx-auto">
          {steps.map((s, i) => (
            <div key={i} className={`flex items-center gap-2 text-sm transition-all ${i <= idx ? 'text-white/70' : 'text-white/20'}`}>
              <span>{i <= idx ? '✓' : '○'}</span>
              <span>{s}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── Editor Step ─────────────────────────────────────────────── */
function EditorStep({ ad, setAd, brand }) {
  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-64px)]">
      {/* Preview panel */}
      <div className="flex-1 bg-black/30 flex items-center justify-center p-8 overflow-auto">
        <AdCanvas ad={ad} />
      </div>
      {/* Editor panel */}
      <div className="w-full lg:w-80 glass border-l border-white/5 overflow-y-auto">
        <AdEditor ad={ad} setAd={setAd} />
      </div>
    </div>
  );
}

/* ─── Editable Field ──────────────────────────────────────────── */
function EditableField({ label, value, onChange, multiline }) {
  return (
    <div>
      <label className="text-xs text-white/40 uppercase tracking-wider mb-1.5 block">{label}</label>
      {multiline ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
          className="w-full bg-white/5 border border-white/8 hover:border-white/15 focus:border-violet-500 rounded-lg px-3 py-2 text-sm text-white placeholder-white/25 outline-none transition-colors resize-none"
        />
      ) : (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-white/5 border border-white/8 hover:border-white/15 focus:border-violet-500 rounded-lg px-3 py-2 text-sm text-white outline-none transition-colors"
        />
      )}
    </div>
  );
}
